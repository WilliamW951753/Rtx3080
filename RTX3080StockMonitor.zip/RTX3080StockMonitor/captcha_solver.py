from amazoncaptcha import AmazonCaptcha
import sys

link = str(sys.argv[1])

captcha = AmazonCaptcha.fromlink(link)
solution = captcha.solve()

print(solution)