package com.johnomeara.rtx;

import java.io.IOException;

public class Notifier {
	public void alert(String url) {
		new Thread(() -> {
			System.out.println("[ALERT] > "+url);
			try {
				HttpUtils.discordAlert(url);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}).start();
	}
}
