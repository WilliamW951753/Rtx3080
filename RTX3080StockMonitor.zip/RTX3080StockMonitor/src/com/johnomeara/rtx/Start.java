package com.johnomeara.rtx;

public class Start {

	public static Notifier notifier = new Notifier();
	
	public static void main(String[] args) throws InterruptedException {
		System.out.println("- RTX 3080 Stock Monitor -");
		new AmazonWatcher();
		new BestBuyWatcher();
	}

}
