package com.johnomeara.rtx;

import java.util.HashMap;

import org.jsoup.Connection;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;

import org.jsoup.select.Elements;

public class AmazonWatcher {
	public AmazonWatcher() {
		new Thread(() -> {
			try {
				watcher();
			} catch (Exception e) {
				e.printStackTrace();
				System.out.println("[AMAZON WATCHER] > Error! Exiting Application...");
				System.exit(0);
			}
		}).start();
	}

	public void watcher() throws Exception {
		HashMap<String, String> cookies = new HashMap<>();
		while (true) {
			System.out.println("[AMAZON WATCHER] > Checking stock...");
			Connection.Response conn = Jsoup.connect("https://www.amazon.com/hz/wishlist/printview/2T4GNMOWBAAQG").cookies(cookies).method(Connection.Method.GET)
			        .followRedirects(false).execute();
			System.out.println("[AMAZON WATCHER] > Status Code: "+conn.statusCode());
			Document doc = conn.parse();
			if (doc.toString().contains("elem.src = prefix + \"csm-captcha-instrumentation.min.js\";")) {
				System.out.println("[AMAZON WATCHER] > Captcha Detected! Processing...");
				cookies = AmazonCaptchaEngine.processCaptcha(doc);
			} else {
				Elements a = doc.select(".a-text-center").select(".a-align-center");
				Elements b = doc.select(".a-align-center");
				int k = 3;
				for(int i = 1; i < a.size()-1; i+= 4) {
					if(!a.get(i).html().equals("-")) {
						String url = b.get(k).text();
						Start.notifier.alert(url);
					}
					k += 7;
				}
			}
			Thread.sleep(10000);
		}
	}
}
