package com.johnomeara.rtx;

import java.io.IOException;
import java.net.URLEncoder;
import java.util.HashMap;
import java.util.List;

import org.jsoup.Connection;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;

public class AmazonCaptchaEngine {
	public static String captres = "";
	
	public static String solveCaptcha(String captchaurl) throws IOException {
		java.util.Scanner s = new java.util.Scanner(
				Runtime.getRuntime().exec("python3 captcha_solver.py " + captchaurl).getInputStream())
						.useDelimiter("\\A");
		String res = (s.hasNext() ? s.next() : "");
		res = res.replaceAll("\n", "");
		captres = res;
		return res;
	}
	
	public static HashMap<String, String> processCaptcha(Document doc) {
		String captcha_id = URLEncoder.encode(doc.select("[name=amzn]").attr("value"));
		String captcha_image_url = doc.select(".a-row img").attr("src");
		String captcha_result = null;
		try {
			captcha_result = solveCaptcha(captcha_image_url);
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		try {
			System.out.println("[AMAZON WATCHER] > Sucessfully Processed Captcha: "+captres);
			return validateAmazonCaptcha("https://www.amazon.com/errors/validateCaptcha?amzn="
					+ captcha_id + "&field-keywords=" + captcha_result);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}
	
	public static HashMap<String, String> validateAmazonCaptcha(String urlstr) throws IOException {
		Connection.Response response = Jsoup
		        .connect(urlstr)
		        .method(Connection.Method.GET)
		        .followRedirects(false)
		        .execute();
		HashMap<String, String> cookies = new HashMap<>();
		if(response.body().contains("elem.src = prefix + \"csm-captcha-instrumentation.min.js\";")){
			return cookies;
		}else {
			List<String> captchaKeys = response.headers("set-cookie");
	 		cookies.put("x-amz-captcha-1",captchaKeys.get(0).split("x-amz-captcha-1=")[1].split(";")[0]);
			cookies.put("x-amz-captcha-2",captchaKeys.get(1).split("x-amz-captcha-2=")[1].split(";")[0]);
			return cookies;
		}
	}
}
