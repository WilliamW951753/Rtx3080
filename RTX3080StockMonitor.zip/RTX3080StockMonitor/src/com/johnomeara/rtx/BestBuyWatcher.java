package com.johnomeara.rtx;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

public class BestBuyWatcher {
	public BestBuyWatcher() {
		new Thread(() -> {
			try {
				watcher();
			} catch (Exception e) {
				e.printStackTrace();
				System.out.println("[BEST BUY WATCHER] > Error! Exiting Application...");
				System.exit(0);
			}
		}).start();
	}

	public void watcher() throws Exception {
		while (true) {
			System.out.println("[BEST BUY WATCHER] > Checking stock...");
			String page = HttpUtils.getBestBuySearchPage();
			if (page.split(">Sold Out<", -1).length - 1 < page.split("list-item lv", -1).length - 1) {
				Document doc = Jsoup.parse(page);
				Elements buttons = doc.select(".add-to-cart-button");
				Elements skulinks = doc.select(".sku-header");
				for (Element button : buttons) {
					if (!button.toString().contains("disabled")) {
						String sku = button.attr("data-sku-id");
						String link = "NO LINK FOUND";
						for (Element skulink : skulinks) {
							if (skulink.toString().contains(sku)) {
								link = "https://www.bestbuy.com/" + skulink.children().first().attr("href");
								break;
							}
						}
						Start.notifier.alert(link);
					}
				}
			}
			Thread.sleep(10000);
		}
	}
}
