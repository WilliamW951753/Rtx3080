package com.johnomeara.rtx;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.List;

import org.jsoup.Connection;
import org.jsoup.Jsoup;

public class HttpUtils {	
	public static String getBestBuySearchPage() throws IOException {
		URL url = new URL("https://www.bestbuy.com/site/searchpage.jsp?qp=videomemorycapacitysv_facet%3DVideo%20Memory%20Capacity~10%20gigabytes&st=rtx%203080");
		HttpURLConnection http = (HttpURLConnection)url.openConnection();
		http.setRequestProperty("authority", "www.bestbuy.com");
		http.setRequestProperty("pragma", "no-cache");
		http.setRequestProperty("cache-control", "no-cache");
		
		http.setRequestProperty("sec-ch-ua-mobile", "?0");
		http.setRequestProperty("upgrade-insecure-requests", "1");
		http.setRequestProperty("user-agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.114 Safari/537.36");
		http.setRequestProperty("accept", "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9");
		http.setRequestProperty("sec-fetch-site", "same-origin");
		http.setRequestProperty("sec-fetch-mode", "navigate");
		http.setRequestProperty("sec-fetch-user", "?1");
		http.setRequestProperty("sec-fetch-dest", "document");
		http.setRequestProperty("accept-language", "en-US,en;q=0.9");
		http.setRequestProperty("cookie", "SID=bdba3da4-7bd4-402b-bb0d-f9ac61103741; pst2=498|N; physical_dma=819; customerZipCode=98004|N; oid=1513867232; vt=e2c15e00-d79e-11eb-9db3-0298e0d2e859; bm_sz=B648C8BAF2EF0890EECC97454F8E32A7~YAAQjS4gF386e/55AQAAjlLKTwxIeUuxuH9lpz9cTw3crwuPU0kafo6fKkxh8uWiPdfA+7t79lLJalEq8MfyfIeReZoHHoE8uMZsXb8mtpc5iUzqIPFdI6o9ju7f3taW8mKZtsf7GJE8C1mFWbidmkwGc1KsGWsBISoLFyXcsEe6YfJQuQXNetdTKrQnet6BeOLvkvSWVstNHIbZvjeDyoCdejEAf62rZVeWV7cG7Fcw2kIwrrN9uzXJJK+1AHpQ/KGiwzpMqie1k7rxuP1f82IftZIQrWIz8q46Iu/q; bby_rdp=l; CTT=33743de3de3e6866334057bf289d4a25; rxVisitor=1624836306498364PGQHEI8LOSIES15M23TTLG84D1MAU; COM_TEST_FIX=2021-06-27T23%3A25%3A44.036Z; CTE10=T; _abck=257E746046356D38CA74FC66A002203E~0~YAAQjS4gFyo+e/55AQAAIlTLTwalxzAYvSwqj6u58IaJS/NKbIXrTZBtrTtz8QA57oZ5FpSlWYf0xQv3YVE+Wvt7Mb+q81W2LQi+Cn1ZuYk+G/1pugSt1uvnxfGtjPvgj1dlN5MNvvKx3vWKEjErMCsUUay0etHSTiAki4JK3VZwzJOpbmeYWncgzwa/bSIjsh4LioGvmO+zzHBWrwfP9zmlmUcDtqN/hQgijlVBcCkpFAbAgdGntwmOk151y1cjVYjHm5ttRGYnTE6Qk3jH2N79JxfJ5SLEGkMrScddxtkJDE8d6hKgYebSVO5g2wooj/d+6V4YsPKo/EFld4XBHTQBXfIDAaKxl3umj3X1jrxmi4kpgpAvGSMlQrKeNtYP3f1FhkP5BhQe4YJtrh9KjBn0tSzovjOz90VGoYl1lCmV3ycyZEUjp2qYFPblwodH~-1~||-1||~-1; CTE22=T; basketTimestamp=1624836368105; partner=198%26Troposphere+LLC%262021-06-27+18%3a26%3a10.000; AMCVS_F6301253512D2BDB0A490D45%40AdobeOrg=1; campaign_date=1624836377733; campaign=198_TroposphereLLC_0; s_ecid=MCMID%7C21952949791205880081431199406744052066; _cs_mk=0.4631921742641836_1624836378904; s_cc=true; AMCV_F6301253512D2BDB0A490D45%40AdobeOrg=1585540135%7CMCMID%7C21952949791205880081431199406744052066%7CMCAAMLH-1625441179%7C9%7CMCAAMB-1625441179%7CRKhpRz8krg2tLO6pguXWp5olkAcUniQYPHaMWWgdJ3xzPWQmdj0y%7CMCOPTOUT-1624843579s%7CNONE%7CMCAID%7CNONE%7CMCCIDH%7C-1935467121%7CvVersion%7C4.4.0; aam_uuid=16814821009824352741945051936003229760; 52245=; _gcl_au=1.1.385558248.1624836380; CRTOABE=1; _cs_c=1; ltc=%20; locDestZip=98004; locStoreId=498; sc-location-v2=%7B%22meta%22%3A%7B%22CreatedAt%22%3A%222021-06-28T00%3A05%3A51.631Z%22%2C%22ModifiedAt%22%3A%222021-06-28T00%3A05%3A51.964Z%22%2C%22ExpiresAt%22%3A%222022-06-28T00%3A05%3A51.964Z%22%7D%2C%22value%22%3A%22%7B%5C%22physical%5C%22%3A%7B%5C%22zipCode%5C%22%3A%5C%2298004%5C%22%2C%5C%22source%5C%22%3A%5C%22A%5C%22%2C%5C%22captureTime%5C%22%3A%5C%222021-06-28T00%3A05%3A51.630Z%5C%22%7D%2C%5C%22destination%5C%22%3A%7B%5C%22zipCode%5C%22%3A%5C%2298004%5C%22%7D%2C%5C%22store%5C%22%3A%7B%5C%22storeId%5C%22%3A498%2C%5C%22zipCode%5C%22%3A%5C%2298005%5C%22%2C%5C%22storeHydratedCaptureTime%5C%22%3A%5C%222021-06-28T00%3A05%3A51.964Z%5C%22%7D%7D%22%7D; bby_suggest_lb=p-suggest-w; dtSa=-; c2=Search%20Results; dtCookie=v_4_srv_5_sn_Q5254NE034BHPUP77IJAPU4GKU4MT4JK_app-3Aea7c4b59f27d43eb_1_app-3A1b02c17e3de73d2a_1_ol_0_perc_100000_mul_1; s_sq=%5B%5BB%5D%5D; bby_cbc_lb=p-browse-w; bby_prc_lb=p-prc-w; rxvt=1624841321287|1624838173509; dtPC=5$39511324_901h-vCUFIDABUIKHOMUFMWAAUBRMHRWCUSSFV-0e6; dtLatC=3; _cs_id=c0dfa739-93bd-a8a2-af2b-61c2699f3595.1624836383.2.1624839535.1624838723.1614963257.1659000383752.Lax.0; _cs_s=5.1");
		http.setConnectTimeout(5000);
		http.disconnect();
		BufferedReader br = new BufferedReader(new InputStreamReader((http.getInputStream()), StandardCharsets.UTF_8));
		StringBuilder sb = new StringBuilder();
		String output;
		while ((output = br.readLine()) != null) {
			sb.append(output);
		}
		String resp = sb.toString();
		System.out.println("[BEST BUY WATCHER] > Status Code: "+http.getResponseCode());
		return resp;
	}
	
	public static void discordAlert(String shopurl) throws IOException {
		URL url = new URL("https://discord.com/api/v8/webhooks/859305316311367690/fJqNkqb_ugsE7GzPLw5rX9E4EkSDx0yLdIiIKUPKbHMOUZ3Bld1jah5bBZlZ_pVFJl_4?wait=true");
		HttpURLConnection http = (HttpURLConnection)url.openConnection();
		http.setRequestMethod("POST");
		http.setDoOutput(true);
		http.setRequestProperty("authority", "discord.com");
		http.setRequestProperty("pragma", "no-cache");
		http.setRequestProperty("cache-control", "no-cache");
		http.setRequestProperty("accept", "application/json");
		http.setRequestProperty("accept-language", "en");
		http.setRequestProperty("sec-ch-ua-mobile", "?0");
		http.setRequestProperty("user-agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.114 Safari/537.36");
		http.setRequestProperty("content-type", "application/json");
		http.setRequestProperty("origin", "https://discohook.org");
		http.setRequestProperty("sec-fetch-site", "cross-site");
		http.setRequestProperty("sec-fetch-mode", "cors");
		http.setRequestProperty("sec-fetch-dest", "empty");
		http.setRequestProperty("referer", "https://discohook.org/");

		String data = "{\"content\":\"@everyone\",\"embeds\":[{\"title\":\"IN STOCK ALERT\",\"description\":\""+shopurl+"\",\"color\":393269}]}";

		byte[] out = data.getBytes(StandardCharsets.UTF_8);

		OutputStream stream = http.getOutputStream();
		stream.write(out);

		http.getResponseCode();
		http.disconnect();
	}
}
